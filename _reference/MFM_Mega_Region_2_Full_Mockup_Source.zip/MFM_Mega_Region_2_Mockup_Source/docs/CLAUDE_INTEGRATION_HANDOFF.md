# MFM Mega Region 2 USA
## Claude Redesign Integration Handoff — Preserve the Original Project

**Purpose:** This is an implementation contract for Claude. It is not a request to generate another independent mockup, React application, artifact, or replacement website.

**Approved direction:** Keep the new photo-forward “Royal Flame” design and its clearer page structure.

**Non-negotiable engineering rule:** Apply that design to the existing MFM Mega Region 2 USA project. The current repository, its static HTML architecture, URLs, data files, JavaScript modules, Netlify integrations, SEO pages, PWA files, and deployment pipeline remain the foundation.

---

## 1. Read This Before Doing Anything

Claude must begin from the original project:

- Repository: `github.com/Logan722/mfm-mega-region2`
- Authoritative branch: `main`
- Host: Netlify
- Netlify publish directory: `.`
- Netlify Functions directory: `netlify/functions`
- Production domain: `mfmmegaregion2usa.org`
- Architecture: framework-free static HTML, shared CSS, and vanilla JavaScript
- Deployment: Netlify automatically deploys pushes to `main`
- There is no frontend compilation or framework build step.

The original website package and repository are the implementation source of truth. The new full-site mockup is a visual and information-architecture reference only. Its code must not replace the original project.

### Required interpretation

This is an **integration and re-skin**, not a greenfield rebuild.

Do not:

- Create a new React, Next.js, Vite, Vue, Svelte, Tailwind, or single-page application.
- Create a new router or replace the existing `.html` URL structure.
- copy an artifact into the repository as a new application.
- flatten all data into one mockup file.
- replace working JavaScript with static cards, sample data, fake buttons, or placeholders.
- remove a working feature because it is difficult to style.
- change hosting, repository, deployment, or serverless architecture.
- rename or remove files, element IDs, data attributes, routes, or global variables without tracing every consumer and receiving approval.
- push experimental work directly to `main`.

If the new visual idea conflicts with a working feature, preserve the feature and adapt the visual design around it. If that cannot be done safely, stop and report the conflict rather than deleting or substituting the feature.

---

## 2. Priority of Authority

When instructions appear to conflict, use this order:

1. The ministry’s latest explicit decisions and verified factual information.
2. The existing production project and its working behavior.
3. The project package documents, especially `03-DECISIONS-KEEP-RESTORE.md`, `04-PAGES-AND-FEATURES.md`, and `05-DATA-DESIGN-ASSETS.md`.
4. The approved Royal Flame design direction and page structure.
5. The self-contained visual mockup/artifact.

The mockup must never overrule production functionality.

---

## 2A. Authoritative Voice-Note Decisions — August 22, 2026

The owner’s 10-minute-23-second review is an authoritative acceptance specification. These requirements correct assumptions made in the earlier mockup and must be reflected in both the visual result and the production integration.

### Header and navigation

- The site header remains deep navy, as in the original website. Do not convert it to a white header.
- Preserve the original desktop dropdown and mobile-drawer information architecture.
- Primary sequence: Home, About, Media & Events dropdown, Ministries dropdown, Connect, Request Prayer.
- Media & Events contains Media, Events, Watch Live, and Prayer Points.
- Ministries contains All Ministries, Gen218, Women Foundation, Youth Ministry, and Branches.
- Youth Ministry continues to the verified external Youth Church website.
- “Request Prayer” replaces the former highlighted Give action. Giving is not promoted anywhere in the redesign.
- Desktop dropdowns and the mobile drawer must retain keyboard, focus, Escape, overlay, close-on-navigation, and scroll-restoration behavior.

### Homepage decisions

- Keep the approved Royal Flame hero, service/programme dock, “What Is Happening Now,” ministry-photo mosaic, latest-message presentation, “Where the Fire Burns,” and lower contact area.
- Event cards expose the actions supported by their event record: Event Details, Get Tickets, and Watch Promo Video. Do not render fake or unavailable actions.
- Restore the pulsing social hub with verified YouTube, Instagram, Facebook, and WhatsApp Channel destinations.
- “Watch & Grow” uses the latest item returned by the existing YouTube RSS flow and retains the current fallback when remote retrieval fails.
- The lower form is presented as “Reach Out to Us,” not only “Request Prayer.” It is still the original Netlify form and defaults to General Message from a general reach-out action.
- Every Request Prayer action opens that same form with Prayer Request selected. Do not create a second prayer-form pipeline.
- Retain Prayer Request, Testimony, pastoral/ministry support, and General Message subject routing. Do not add a giving subject or donation flow.

### About and leadership

- Keep the approved simple About-page presentation without deleting original content.
- Correct portrait crops individually. Pastor Olumide Oni’s portrait must be centered deliberately with excessive headroom removed; do not apply one generic `object-position` to every leader.
- Restore every verified leadership social/profile link from the original page.

### Programs and events

- The Royal Flame Programs presentation is approved.
- “See Current Schedule” opens an accessible in-page popup for that programme. It must not redirect to Events and force the visitor to find the programme again.
- Events continue to use `MFM_EVENTS`; ticket, promo-video, schedule, modal, calendar, share, time-zone and detail-page behavior remain driven by each event record.

### Watch behavior

- Watch Live points to the dedicated `watch.html` experience.
- The player uses the existing channel RSS/latest-video pipeline and regularly rechecks it.
- The page clearly distinguishes Loading, Next Scheduled Service, Live Now, Latest Available Service, and Retrieval Failed/fallback states.
- During a verified broadcast window, the live action directs visitors to the channel’s live endpoint and the page refreshes/resynchronizes without requiring manual navigation.

### Ministries and Connect

- Women Foundation opens `women.html`; Gen218 opens `gen218.html`; Youth Ministry opens the verified Youth Church website.
- `links.html` remains the real Connect page. Re-skin its complete YouTube, WhatsApp, Facebook, Instagram, regional-contact, church-finder and reach-out pathways; do not replace it with a placeholder card grid or remove the page.

### Required proof before handoff

The owner must be able to click and review these behaviors in the working redesign preview before the implementation package is handed to Claude. A written promise or static placeholder is not acceptance evidence.

## 2B. Authoritative Voice-Note Decisions — August 24, 2026

These decisions are newer than Section 2A and supersede any earlier statement that conflicts with them.

### Newsletter

- Restore the existing newsletter popup on `events.html` only.
- Preserve `js/newsletter-popup.js`, `/.netlify/functions/subscribe`, the honeypot, inline validation, success/error states, the permanent subscribed flag, and 14-day dismissal suppression.
- Re-skin the popup in Royal Flame; do not create a second mailing-list form or service.
- The popup must never cover an already-open event detail modal.

### Homepage event spotlight

- Replace the ordinary multi-card “What Is Happening Now” presentation with an event spotlight carousel driven directly by `MFM_EVENTS`.
- Each slide uses a split editorial layout: official flyer on the left; status, title, theme, date, time, venue, description, and supported actions on the right.
- Render only actions supported by the event record: Event Details, Get Tickets/Register, and Watch Promo.
- Rotate approximately every 7–8 seconds. Include previous/next controls, visible position indicators, touch swipe, pause on hover/focus/manual interaction, and complete `prefers-reduced-motion` support.
- Do not rotate every historical event. Select current, ongoing, featured, and nearest-upcoming records through the same status/date logic used elsewhere.

### Homepage ministry photography

- Choir and Band are not separate categories in the “Life Across the Region” mosaic.
- Use the sequence: Worship; Choir & Live Worship; Youth Church; Prayer & Deliverance; The Word.
- Youth Church requires a genuine, approved Youth & Young Adult Church photograph. Do not relabel the choir photograph as youth.
- Store the approved youth photograph inside the existing local image/WebP pipeline. Do not hotlink the production asset from another website.

### Watch and Prepare

- Each promotional video must be attached to its actual `MFM_EVENTS` record rather than presented with generic copy.
- Display event title, date, venue, theme, minister/host, a meaningful description, Event Details, and Register/Get Tickets when available.
- Retain the existing click-to-load video behavior and do not create an unrelated second event dataset.

### About and leadership

- Compact name/title-only leadership cards are not sufficient.
- Restore the original biography content for all four leaders together with the approved portraits, exact titles, individual crops, and verified social/profile links.
- Present Dr. D.K. Olukoya and Pastor (Dr.) Mrs. Shade Olukoya as paired global-leadership profiles.
- Present Pastor Olumide Oni and Pastor (Mrs.) Oluwatoyin Oni in fuller alternating editorial profiles suitable for their regional roles.
- Do not generate new biography facts. Use the current approved `about.html` content.

### Events interaction

- On `events.html`, selecting an event opens the existing in-page event detail sheet/modal. It must not replace the page with a new detail route.
- Preserve flyer, complete programme information, minister/host, registration, promo video, Add to Calendar, Share, gallery/lightbox, directions where available, and status.
- Preserve shareable hash anchors such as `events.html#event-anchor`; opening a hash must scroll/select appropriately and open the same modal.
- Preserve Escape, backdrop close, focus trap, focus return, page scroll lock, and full-screen mobile-sheet behavior.
- Static `events/*.html` and `share/*.html` pages remain for SEO, social previews, direct links, and no-JavaScript fallback; they do not replace the modal interaction on `events.html`.

### Women Foundation

- Restore the verified Facebook and Instagram links for Pastor (Dr.) Mrs. Shade Olukoya.
- Restore the verified Facebook, Instagram, and YouTube links for Pastor (Mrs.) Oluwatoyin Oni.
- Keep approved biographies and titles visible with their leadership profiles.

### Connect page — latest decision

- `links.html` remains the original standalone link hub. Do not convert it into a contact/information page.
- Keep the Website, YouTube, WhatsApp Channel, Facebook, Instagram, and Branches destinations in the original link-hub structure.
- Remove the additional Regional Office panel, Reach Out form, New Here pathway cards, and other sections introduced by the mockup.
- Giving remains excluded; omit the Give tile without replacing it with a new giving or payment path.
- The main Reach Out and Request Prayer form routes continue elsewhere in the website; they are not embedded into `links.html`.

---

## 3. Protected Project Architecture

The following structure must remain intact:

### Primary pages

- `index.html`
- `about.html`
- `branches.html`
- `ministries.html`
- `women.html`
- `gen218.html`
- `media.html`
- `events.html`
- `links.html`
- `watch.html`
- `privacy.html`
- `thanks.html`
- `404.html`
- `_template.html`

`give.html` is outside the redesign scope. Do not redesign, expand, promote, or add a payment system. Preserve the file and any existing inbound URLs so nothing breaks.

### Static detail-page families

- `branches/*.html` — 34 branch/Youth Church pages
- `events/*.html` — individual event pages
- `messages/*.html` — individual message pages
- `share/*.html` — social-sharing pages

These static pages are intentional. They support SEO, social previews, direct links, and visitors without JavaScript. Do not replace them with client-side routes.

### Shared styling and runtime

- `css/site.css`
- `css/events-cards.css`
- `js/site.js`
- `js/events-data.js`
- `js/media-data.js`
- `js/dept-events.js`
- `js/newsletter-popup.js`

The redesigned homepage currently contains Royal Flame styles scoped beneath `#rf`. For the interior-page rollout, create or extend a shared, namespaced Royal Flame stylesheet if helpful, but do not delete `site.css` or break its global navigation, drawer, footer, accessibility, social hub, live banner, and utility behavior.

### Hosting, backend, CMS, PWA, and discovery files

- `netlify.toml`
- `netlify/functions/subscribe.js`
- `netlify/functions/instagram-feed.mjs`
- `netlify/functions/instagram-refresh.mjs`
- `netlify/functions/brevo-admin.js`
- `admin/index.html`
- `admin/config.yml`
- `sw.js`
- `manifest.json`
- `sitemap.xml`
- `robots.txt`
- `package.json`

Do not activate the CMS, change environment-variable names, alter Netlify Function contracts, or modify the deployment configuration as part of the redesign.

---

## 4. Protected Data Pipeline

The website already has single sources of truth. Keep them.

### Events

`js/events-data.js` exposes `window.MFM_EVENTS` and supplies the homepage, events page, Women Foundation page, Gen218 page, event detail pages, share pages, and crawlable fallbacks.

Do not copy event information into new independent arrays or hard-code different versions into page markup. Visual components must render from `MFM_EVENTS`.

When event data changes, the corresponding detail pages, share pages, `<noscript>` fallbacks, schema, breadcrumbs, and sitemap must remain synchronized.

### Media

`js/media-data.js` exposes `window.MFM_MEDIA` and powers the media library and message pages.

Do not replace it with static mock cards. Preserve search and all filters: program, speaker, topic, and year.

### Department events

`js/dept-events.js` filters `MFM_EVENTS` for Women Foundation and Gen218. Preserve `[data-dept-events="women"]` and `[data-dept-events="gen218"]`, status chips, calendar actions, and sharing.

### Branches

The canonical directory is the 34 `.dir-row` records in `branches.html`, including state, latitude, longitude, type, pastor, address, services, phone, and social information.

The map, search, state filters, distance calculations, modal, deep links, and branch pages must continue to use this verified data. Do not create a second branch list for the redesign.

Reconcile the public count carefully: 33 branches across six states plus one Youth Church. Do not invent or silently change the count.

### Factual content

Follow the one-fact-one-place rule. Dates, service times, addresses, pastors, titles, and counts must come from their authoritative structured fields. Narrative copy must not introduce competing facts.

---

## 5. DOM and Behavior Contracts That Must Survive

The redesign may change presentation, but the following selectors and contracts must remain or be deliberately migrated with every caller updated and tested:

- Homepage: `#rf`, `#new-here`, `#visit`, `#prayer`, `#reachForm`, `#reachSuccess`, and existing `data-vid` controls.
- Branches: `#branchMap`, `#dirZipForm`, `#dirSearch`, state-filter `data-filter` controls, `.dir-row`, branch hashes, modal triggers, and modal focus behavior.
- Media: `#mediaLibraryGrid`, `window.MFM_MEDIA`, dropdown filters, search, quick-filter chips, clear state, recent YouTube loading, and fallback state.
- Events: `window.MFM_EVENTS`, event anchors, `data-flyer`, event modal, gallery/lightbox, promo video, Add-to-Calendar, Share, toast, hash deep links, and `data-ct-base` time conversion.
- Women/Gen218: `[data-dept-events]`, ministry tags, calendar/share actions, approved portraits, and YouTube playlists.
- Watch: `#livePlayer`, recent-video retrieval, timeout/fallback behavior, and service schedule.
- Newsletter: events-page-only loading of `js/newsletter-popup.js`, honeypot, localStorage suppression, and the `/.netlify/functions/subscribe` contract.
- Site-wide: sticky navigation, dropdowns, mobile drawer and overlay, active-page state, skip link, focus visibility, social FAB, live banner, back-to-top, reduced-motion handling, Plausible analytics, and service-worker registration.

If a selector is changed for semantic or accessibility reasons, provide a migration table showing the old selector, new selector, every file updated, and the passing test that proves parity.

---

## 6. Approved Visual Direction

Keep the new photo-forward Royal Flame language:

- Deep/twilight navy for authority and cinematic sections.
- Cream and white for reading and breathing space.
- Bright gold and fire orange for decoration, large display accents, and live states.
- Dark gold `#8F6212` and dark fire `#B3471B` for small text on light backgrounds.
- Fraunces for major editorial titles and scripture statements.
- Inter Tight for navigation, forms, metadata, cards, directories, and body copy.
- Strong ministry photography, restrained transitions, subtle grain/light shafts on navy, and consistent component spacing.

Use the official MFM emblem and wordmark as identity. A decorative flame may appear only as an accent, never as a replacement logo.

Content must be visible in the base state. Animations may enhance content but must never create an empty page when JavaScript, IntersectionObserver, or motion fails. Respect `prefers-reduced-motion`.

### Photography

Use the existing local asset pipeline, not remote hotlinks. Preserve WebP plus JPG/PNG fallback through `<picture>` where already used.

- Only the true hero/LCP image is eager and high priority.
- Below-the-fold images use `loading="lazy"`.
- Supply intrinsic width/height to prevent layout shift.
- Add responsive `srcset` and `sizes`.
- Use consistent crops: hero wide editorial; event/ministry cards 4:3; leadership 4:5; message thumbnails 16:9.
- Provide a deliberate fallback so missing images never create a blank full-screen section.

Approved leadership portraits:

- `img/photos/Daniel Olukoya 2.png`
- `img/photos/shade olukoya.jpeg`
- `img/photos/pastor-oni-gold.jpg`
- `img/photos/mrs-oni-burgundy.jpg`
- `img/photos/pastor-obatunsin.jpg`

Never replace these leaders with initials, generated people, or stock portraits.

Authoritative titles:

- Pastor Olumide Oni — **Principal Regional Overseer, Mega Region 2 USA**
- Pastor (Mrs.) Oluwatoyin Oni — **President, MFM Women Foundation, Mega Region 2 USA**
- Dr. D.K. Olukoya — **General Overseer, MFM Worldwide**
- Pastor (Dr.) Mrs. Shade Olukoya — **Mummy G.O. / International President, MFM Women Foundation**

---

## 7. Page-by-Page Integration Requirements

### Home — `index.html`

Keep the new photo-forward hero and page hierarchy, but integrate it with the existing homepage pipeline.

Required restoration:

- Real newcomer section at `#new-here`.
- Real Plan Your Visit section at `#visit`, including service information and map/directions.
- Real Netlify prayer/contact form at `#prayer`/the Reach Out section with `#reachForm`, honeypot, subject choices, AJAX handling, and `#reachSuccess`. General reach-out actions default to General Message; Request Prayer actions default to Prayer Request.
- Two promotional YouTube videos through the existing `data-vid` behavior.
- A split-layout “What Is Happening Now” spotlight carousel rendered from `MFM_EVENTS`, including correct status, Event Details, Get Tickets when present, Watch Promo Video when present, accessible controls, pause behavior, reduced-motion behavior, touch swipe, directions, sharing, and calendar actions.
- “Life Across the Region” uses Worship, Choir & Live Worship, Youth Church, Prayer & Deliverance, and The Word. Use a real approved youth photograph through the local image pipeline.
- The two promotional video panels show their real event title, date, venue, theme, minister/host, description, Event Details, and registration action when present.
- The verified pulsing/fan-out social hub with YouTube, Instagram, Facebook, and WhatsApp Channel.
- The latest YouTube item loaded through the existing RSS/fallback behavior in Watch & Grow.

Routing:

- “I’m New” must lead to the newcomer/visit experience, not About.
- “Watch Live” must lead to `watch.html` only when appropriate.
- When no service is live, use “Watch” or “Latest Message”; do not falsely display a live state.
- “Find a Church” leads to `branches.html`.

### About — `about.html`

Apply the new visual system without removing Who We Are, the three fires, Obadiah 1:17, the 11-part mandate, or the leadership section. Use the approved portraits and exact titles. Restore the approved original biography content for every leader and preserve verified leader social/profile buttons. Use paired global-leadership profiles followed by fuller alternating profiles for Pastor Olumide Oni and Pastor (Mrs.) Oluwatoyin Oni. Art-direct each portrait crop separately, including correcting Pastor Olumide Oni’s excess headroom.

### Find a Church — `branches.html`

The directory is not a card mockup. Re-skin the real working system:

- Leaflet/OpenStreetMap map and custom pins.
- Browser geolocation and nearest branch.
- ZIP/city search through Nominatim and distance ranking.
- Text search and state filters.
- Branch modal, deep links, keyboard behavior, focus trap/return, sharing, directions, and static branch pages.

The new design must wrap these functions; it must not replace them with a static map image.

### Programs and Events — `events.html`

Keep the redesigned visual hierarchy while preserving the `MFM_EVENTS` pipeline, status computation, modal, lightbox/gallery, promo video, Add-to-Calendar, Share, deep links, Event schema, and DST-aware Fire Across Time Zones table.

Programme cards that expose “See Current Schedule” must open the selected programme’s accessible schedule dialog in place. Do not redirect to `events.html` and make the visitor search a second time. The dialog must support keyboard focus, Escape close, backdrop close, focus return, and mobile scrolling.

All date/status logic must use an explicit ministry time-zone rule so “Today,” “Tomorrow,” “This Week,” and “Ongoing” are correct around midnight and across US time zones.

The newsletter popup remains exclusive to this page.

Selecting an event card on this page opens the original in-page detail sheet/modal; it does not navigate away. Hash links open the same modal. Preserve the static detail/share pages as SEO, social, direct-link, and no-JavaScript fallbacks.

### Media and Watch — `media.html`, `watch.html`, `messages/*.html`

Preserve the complete searchable/filterable library, recent YouTube loading, resilient fallbacks, Instagram feed, dedicated message pages, VideoObject/breadcrumb metadata, and live/recent player behavior.

The photo-forward design may improve thumbnails and featured-message presentation, but no static placeholder may replace the player or filters.

The Watch page must show explicit Loading, Next Scheduled Service, Live Now, Latest Available Service, and Retrieval Failed/fallback states. Reuse the current channel ID, RSS retrieval, bounded timeouts and fallback. Recheck the feed on a sensible interval and link the live action to the verified YouTube live endpoint during the active service window.

### Ministries — `ministries.html`, `women.html`, `gen218.html`

Preserve the ministry structure, approved logos/portraits, department event feeds, pillars/categories, messages/playlists, calendar/share controls, and external Youth Ministry link. Do not convert Women Foundation or Gen218 into generic description cards. The Women Foundation page must show the verified Facebook and Instagram links for Pastor Shade Olukoya and Facebook, Instagram, and YouTube links for Pastor Oluwatoyin Oni.

### Connect — `links.html`

Re-skin the existing standalone link hub without adding unrelated page sections. Retain Visit the Website, YouTube, WhatsApp Channel, Facebook, Instagram, and Branches. Remove the mockup’s Regional Office panel, Reach Out form, New Here/pathway cards, and other added contact-page sections. Giving remains excluded, so omit the Give tile. Request Prayer and Reach Out continue through their established site-wide form pathways, not inside `links.html`.

### Giving — `give.html`

Out of scope. Make no design, payment, content, or navigation expansion. Keep the existing file and inbound route functioning, but do not expose Give in the redesigned primary navigation, homepage quick actions, contact subjects, or prominent calls to action. The highlighted header action is Request Prayer.

---

## 8. Safe Implementation Workflow for Claude

### Stage 0 — Confirm the correct foundation

Before editing, Claude must report:

- The repository/path being edited.
- The current branch.
- Confirmation that it is the original static HTML/vanilla-JS project.
- The presence of `index.html`, `css/site.css`, `js/site.js`, `js/events-data.js`, `branches.html`, `events.html`, `media.html`, `netlify.toml`, and `sw.js`.
- A clean or fully explained working-tree status.

If these checks fail, stop. Do not build a substitute project.

### Stage 1 — Produce an integration map before code

Claude must create a table for every page containing:

- Existing file.
- Existing working sections/features.
- New visual components to apply.
- IDs/data attributes/scripts that must be preserved.
- Expected user journeys.
- Test needed to prove parity.

No source change should begin until this map is complete.

### Stage 2 — Protect deployment

- Create a dedicated integration branch, for example `redesign-integration`.
- Do not push unfinished work to `main`, because `main` auto-deploys to production.
- Make small page-scoped commits.
- Do not combine architecture changes, data changes, content rewrites, and visual changes in one commit.

### Stage 3 — Establish shared Royal Flame components

Extract or extend the existing `#rf` design language into a shared, namespaced stylesheet without removing the working global CSS. Establish reusable classes for page heroes, editorial sections, cards, buttons, media, forms, filters, and image treatments.

Do not duplicate entire style blocks independently inside every page.

### Stage 4 — Integrate page by page

Suggested order based on risk:

1. About and Ministries — establish interior-page visual components.
2. Women and Gen218 — prove department feeds and portrait handling survive.
3. Media and Watch — prove data filters, remote fallbacks, and players survive.
4. Events — prove modals, galleries, status, sharing, calendar, newsletter, and time zones survive.
5. Branches — prove the complete map/search/geolocation/modal system survives.
6. Home — fold the restored visitor, prayer, video, event, and visit systems into the approved design.
7. Static detail/share pages, SEO consistency, sitemap, PWA, and final regression pass.

This order is not a delivery timeline. It is a risk-control sequence.

### Stage 5 — Verify before proposing merge

Claude must not report a page “done” because it looks correct. It is done only when the preservation tests pass.

---

## 9. Mandatory Acceptance Gates

### Architecture and pipeline

- Original static HTML architecture retained.
- No new frontend framework or SPA router.
- Netlify publish/functions configuration unchanged unless separately approved.
- Existing Netlify Function endpoints and environment-variable names preserved.
- No secrets committed.
- `main` not used for experimental work.

### Functional parity

- All primary and static detail routes resolve.
- Branch map, geolocation, ZIP search, state filters, modal, deep links, directions, and branch pages work.
- Media search and program/speaker/topic/year filters work.
- Events status, modal, gallery, promo video, calendar, share, newsletter, schema, and time zones work.
- Women/Gen218 event feeds and message playlists work.
- Watch player loads recent content or displays the designed fallback.
- Homepage newcomer, visit, promo videos, events, and prayer form work.
- Mobile drawer closes correctly and restores page scrolling.
- Social hub and time-gated live banner work.
- Service worker registers and offline fallback remains available.

### Content and identity

- Official MFM emblem/wordmark used.
- All leadership portraits are real and approved.
- All titles match the authoritative list.
- Branch count and Youth Church classification are consistent.
- No invented pastors, times, addresses, event facts, links, or ministry claims.
- No Zoom credentials exposed in indexable text or flyers.

### Accessibility

- WCAG 2.2 AA color contrast.
- Skip link and visible focus retained.
- Keyboard navigation for drawer, dropdowns, cards, branch rows, dialogs, galleries, and forms.
- Dialog focus trap, focus return, Escape close, and correct ARIA states.
- Reduced-motion support.
- Content visible when animation or JavaScript enhancement fails.

### Performance and resilience

- LCP hero alone is eager; below-fold media is lazy.
- Responsive local images with intrinsic dimensions.
- No remote hotlinks for ministry assets.
- No blank sections while images, YouTube, Instagram, RSS, geocoding, or Netlify Functions load or fail.
- Designed loading, empty, error, success, live, and offline states.
- Target LCP ≤2.5s, INP ≤200ms, CLS ≤0.1 at the 75th percentile.

### SEO and sharing

- Canonical, Open Graph, Twitter, JSON-LD, breadcrumbs, and page-specific metadata retained.
- Static branch, event, message, and share pages retained.
- `<noscript>` fallbacks remain synchronized.
- Sitemap and robots remain correct.

### Responsive review

Verify the actual pages—not only the CSS—at approximately 360, 390, 768, 1024, and desktop widths. Check iPhone Safari and Android Chrome where available.

---

## 10. Required Claude Handoff After Implementation

Claude must return:

1. A concise summary of what was integrated.
2. A complete list of modified files.
3. A feature-preservation matrix showing each protected capability and its passing evidence.
4. A list of routes and devices tested.
5. Accessibility and performance results.
6. Any remaining blockers requiring ministry content or approval.
7. Before/after screenshots of representative pages.
8. Confirmation that no framework, routing, data-pipeline, hosting, or deployment substitution occurred.

“The page looks similar to the mockup” is not sufficient evidence.

---

## 11. Stop Conditions

Claude must stop and ask before proceeding if:

- It is not operating in the original repository/project.
- It proposes a framework migration or new hosting platform.
- A design requires removing or replacing a working feature.
- A data field, branch fact, title, service time, event status, or portrait is uncertain.
- A selector change would break an existing JavaScript consumer.
- It cannot preserve a Netlify Function, form, map, feed, player, PWA, SEO page, or accessibility behavior.
- It discovers unrelated existing modifications in files it needs to edit.
- It is about to push unfinished redesign work to `main`.

The correct response to uncertainty is to flag it—not invent, delete, flatten, or silently substitute.

---

## Final Instruction to Claude

**Build the new design inside the old house. Do not demolish the house and recreate its appearance somewhere else.**

The original MFM Mega Region 2 USA project supplies the structure, routes, content pipeline, integrations, accessibility, SEO, PWA behavior, and deployment system. The Royal Flame mockup supplies the visual direction and improved organization. The finished website must contain both.

Do not begin by generating code. Begin by auditing the original project and returning the Stage 0 confirmation and Stage 1 integration map.
