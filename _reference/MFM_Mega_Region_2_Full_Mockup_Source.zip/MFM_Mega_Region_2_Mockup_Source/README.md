# MFM Mega Region 2 USA — Full-Site Mockup Source

This package contains the complete source code for the approved website mockup:

- Home
- About
- Find a Church
- Programs
- Events and event detail states
- Watch
- Ministries
- Women Foundation
- Gen218
- Connect

## Important implementation instruction

This code is the **visual and interaction reference** for the redesign. It must
not replace the existing production website architecture or erase its working
features.

When handing this package to Claude, include
`docs/CLAUDE_INTEGRATION_HANDOFF.md`. That document is authoritative for how to
apply this design to the existing static HTML, vanilla JavaScript, Netlify and
GitHub pipeline while preserving the original forms, branch map, media filters,
feeds, routes, analytics, PWA support and SEO.

## Run the mockup locally

Requirements:

- Node.js 22.13 or newer
- npm

From this folder:

```bash
npm install
npm run dev
```

Open the local address shown in the terminal.

To create a production build:

```bash
npm run build
```

## Main source files

- `app/site.tsx` — pages, content, navigation and interactions
- `app/globals.css` — complete Royal Flame design system and responsive styles
- `app/data.ts` — shared mockup content and data
- `app/page.tsx` — root page entry
- `app/[...slug]/page.tsx` — multi-page routing entry
- `app/layout.tsx` — document metadata and global layout
- `public/` — packaged visual assets and social-preview image

## Mockup-only behavior

The newsletter and form submissions demonstrate interface states. The
production implementation must reconnect them to the original Netlify forms
and existing submission logic.

Some factually specific photographs are referenced from official ministry
sources for preview purposes. Before production deployment, place approved
copies inside the original website's image pipeline, generate responsive
variants, and avoid permanent hotlinking.

## Design features represented

- Royal Flame photo-forward visual direction
- Responsive full-site navigation
- Accessible event spotlight carousel
- Events-page newsletter popup
- In-page event details with calendar, sharing and hash deep links
- Expanded leadership biographies and social links
- Women Foundation leadership and social links
- Youth Church photography
- Detailed Watch & Prepare event panels
- Links-only Connect page
- Page-position reset during navigation
- Mobile, keyboard and reduced-motion considerations
- No giving section

## Production handoff

Claude should use the mockup for appearance and interaction behavior, then
implement those decisions within the original project. The working production
systems must be preserved and enhanced—not rebuilt from this preview starter.
