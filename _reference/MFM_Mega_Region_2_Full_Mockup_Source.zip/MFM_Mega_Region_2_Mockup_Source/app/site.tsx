"use client";

import {FormEvent,useEffect,useMemo,useRef,useState} from "react";
import {art,branches,events,LIVE,messages,photo,programs,type Branch,type EventItem,type MessageItem} from "./data";

type IconName="arrow"|"pin"|"play"|"calendar"|"search"|"clock"|"church"|"heart"|"menu"|"close"|"external"|"mail"|"share"|"check";
function Icon({name}:{name:IconName}){
  const paths:Record<IconName,React.ReactNode>={
    arrow:<><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>,
    pin:<><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></>,
    play:<><circle cx="12" cy="12" r="9"/><path d="m10 8 6 4-6 4V8Z"/></>,
    calendar:<><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/></>,
    search:<><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    clock:<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    church:<><path d="M4 21V10l8-6 8 6v11M9 21v-6h6v6M12 4V1m-2 2h4"/></>,
    heart:<path d="M20.8 8.6a4.4 4.4 0 0 0-7.6-3 4.4 4.4 0 0 0-7.6 3c0 4.6 7.6 9.4 7.6 9.4s7.6-4.8 7.6-9.4Z"/>,
    menu:<><path d="M4 7h16M4 12h16M4 17h16"/></>,
    close:<><path d="m6 6 12 12M18 6 6 18"/></>,
    external:<><path d="M14 4h6v6M20 4l-9 9"/><path d="M18 13v6H5V6h6"/></>,
    mail:<><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></>,
    share:<><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="m8.2 10.8 7.5-4.4M8.2 13.2l7.5 4.4"/></>,
    check:<path d="m5 12 4 4L19 6"/>,
  };
  return <svg viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

function Header({path}:{path:string}){
  const [open,setOpen]=useState(false);
  const close=()=>setOpen(false);
  const mediaActive=["media","messages","events","watch"].some(x=>path===x||path.startsWith(x+"/"));
  const ministriesActive=path==="ministries"||path.startsWith("ministries/")||path==="women"||path==="gen218";
  return <>
    <div className="preview-ribbon"><span>Royal Flame integration preview</span><b>New design · original feature structure</b></div>
    <header className="site-header">
      <a className="brand" href="/" aria-label="MFM Mega Region 2 USA home">
        <img src={`${LIVE}/img/logo.webp`} alt="MFM Mega Region 2 USA official emblem" width="52" height="52"/>
        <span><strong>MFM Mega Region 2 USA</strong><small>Mountain of Fire & Miracles Ministries</small></span>
      </a>
      <button className="menu-toggle" aria-label={open?"Close menu":"Open menu"} aria-expanded={open} onClick={()=>setOpen(v=>!v)}><Icon name={open?"close":"menu"}/></button>
      <nav className={open?"nav open":"nav"} aria-label="Primary navigation">
        <a className={!path?"active":""} href="/" onClick={close}>Home</a>
        <a className={path==="about"?"active":""} href="/about" onClick={close}>About</a>
        <details className={mediaActive?"nav-dropdown active":"nav-dropdown"}>
          <summary>Media &amp; Events <span aria-hidden="true">⌄</span></summary>
          <div className="nav-dropdown-menu">
            <a href="/media" onClick={close}><b>Media</b><small>Sermons, worship &amp; teachings</small></a>
            <a href="/events" onClick={close}><b>Events</b><small>Weekly programmes &amp; special services</small></a>
            <a href="/watch" onClick={close}><b>Watch Live</b><small>Join our services online</small></a>
            <a href="https://www.mountainoffire.org/resources/prayer-points" target="_blank" rel="noreferrer" onClick={close}><b>Prayer Points</b><small>Daily prayer points from MFM</small></a>
          </div>
        </details>
        <details className={ministriesActive?"nav-dropdown active":"nav-dropdown"}>
          <summary>Ministries <span aria-hidden="true">⌄</span></summary>
          <div className="nav-dropdown-menu">
            <a href="/ministries" onClick={close}><b>All Ministries</b><small>Overview of our ministry arms</small></a>
            <a href="/ministries/gen218" onClick={close}><b>Gen218</b><small>Christian singles ministry</small></a>
            <a href="/ministries/women" onClick={close}><b>Women Foundation</b><small>Women’s ministry &amp; conferences</small></a>
            <a href="https://www.mfmmegaregion2yc.org/" target="_blank" rel="noreferrer" onClick={close}><b>Youth Ministry</b><small>Mega Region 2 Youth Church</small></a>
            <a href="/locations" onClick={close}><b>Branches</b><small>Find a church near you</small></a>
          </div>
        </details>
        <a className={path==="connect"||path==="links"?"active":""} href="/connect" onClick={close}>Connect</a>
        <a className="drawer-prayer" href="/prayer" onClick={close}><Icon name="heart"/> Request Prayer</a>
      </nav>
      <a className="nav-action" href="/prayer"><Icon name="heart"/> Request Prayer</a>
    </header>
  </>;
}

const ministrySocials=[
  {label:"YouTube",short:"YT",href:"https://youtube.com/@mfmmegaregion2usa",kind:"youtube"},
  {label:"Instagram",short:"IG",href:"https://www.instagram.com/mfmmegaregion2usa",kind:"instagram"},
  {label:"Facebook",short:"FB",href:"https://www.facebook.com/profile.php?id=61556716678081",kind:"facebook"},
  {label:"WhatsApp Channel",short:"WA",href:"https://whatsapp.com/channel/0029VaO63PADJ6H057Ikrl3G",kind:"whatsapp"},
];

function SocialHub(){
  const [open,setOpen]=useState(false);
  return <div className={open?"social-hub open":"social-hub"}>
    <div className="social-hub-links">{ministrySocials.map(s=><a className={s.kind} href={s.href} target="_blank" rel="noreferrer" aria-label={s.label} key={s.label}><span>{s.label}</span><b>{s.short}</b></a>)}</div>
    <button type="button" aria-label={open?"Close ministry social links":"Open ministry social links"} aria-expanded={open} onClick={()=>setOpen(v=>!v)}><Icon name={open?"close":"share"}/></button>
  </div>
}

function Footer(){return <footer className="site-footer">
  <div className="footer-grid wrap">
    <div className="footer-identity"><img src={`${LIVE}/img/logo.webp`} alt="" width="64" height="64"/><div><strong>MFM Mega Region 2 USA</strong><p>Prayer · Deliverance · The Word</p></div><blockquote>“But upon mount Zion shall be deliverance, and there shall be holiness.” <span>Obadiah 1:17</span></blockquote></div>
    <div><b>Explore</b><a href="/about">About</a><a href="/locations">Find a Church</a><a href="/programs">Programs</a><a href="/events">Events</a></div>
    <div><b>Ministries</b><a href="/ministries/women">Women Foundation</a><a href="/ministries/gen218">Gen218 Singles</a><a href="https://www.mfmmegaregion2yc.org/" target="_blank" rel="noreferrer">Youth Church</a><a href="/watch">Watch</a></div>
    <div><b>Connect</b><a href="/new-here">New Here?</a><a href="/prayer">Prayer Request</a><a href="/reach-out">Reach Out to Us</a><a href="/connect">Contact & Social</a><a href="/privacy">Privacy</a></div>
  </div>
  <div className="footer-bottom wrap"><span>© 2026 MFM Mega Region 2 USA</span><span>Visual integration reference · Original project remains canonical</span></div>
  </footer>}

function Shell({path,children}:{path:string;children:React.ReactNode}){return <><a className="skip-link" href="#content">Skip to content</a><Header path={path}/><main id="content">{children}</main><Footer/><SocialHub/></>}

function Button({href,children,light=false}:{href:string;children:React.ReactNode;light?:boolean}){const external=/^https?:\/\//.test(href);return <a className={light?"button light":"button"} href={href} target={external?"_blank":undefined} rel={external?"noreferrer":undefined}>{children}<Icon name={external?"external":"arrow"}/></a>}
function Eyebrow({children,light=false}:{children:React.ReactNode;light?:boolean}){return <p className={light?"eyebrow light":"eyebrow"}>{children}</p>}

type SocialLink=[label:string,href:string];
function LeaderSocials({name,links}:{name:string;links:SocialLink[]}){return <div className="leader-socials">{links.map(([label,href])=><a href={href} target="_blank" rel="noreferrer" aria-label={`${name} ${label}`} key={label}>{label}</a>)}</div>}

function eventCalendarUrl(e:EventItem){return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(e.title)}&details=${encodeURIComponent(`${e.theme}\n\n${e.description}`)}&location=${encodeURIComponent(e.venue)}`}

function EventModal({event,onClose}:{event:EventItem;onClose:()=>void}){
  const closeRef=useRef<HTMLButtonElement>(null);
  const [copied,setCopied]=useState(false);
  useEffect(()=>{
    const previous=document.body.style.overflow;
    document.body.style.overflow="hidden";
    closeRef.current?.focus();
    const key=(e:KeyboardEvent)=>{if(e.key==="Escape")onClose()};
    document.addEventListener("keydown",key);
    return()=>{document.removeEventListener("keydown",key);document.body.style.overflow=previous};
  },[onClose]);
  async function share(){
    const url=`${window.location.origin}/events#${event.slug}`;
    try{if(navigator.share)await navigator.share({title:event.title,text:event.theme,url});else{await navigator.clipboard.writeText(url);setCopied(true);setTimeout(()=>setCopied(false),1800)}}catch{}
  }
  return <div className="event-modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}>
    <section className="event-modal" role="dialog" aria-modal="true" aria-labelledby="event-modal-title">
      <button ref={closeRef} className="event-modal-close" type="button" aria-label="Close event details" onClick={onClose}><Icon name="close"/></button>
      <div className="event-modal-flyer"><img src={art(event.image)} alt={`${event.title} official event flyer`}/><span>{event.status}</span></div>
      <div className="event-modal-copy">
        <Eyebrow>Regional event</Eyebrow><h2 id="event-modal-title">{event.title}</h2><p className="event-modal-theme">{event.theme}</p>
        <div className="event-modal-meta"><span><Icon name="calendar"/>{event.date}</span><span><Icon name="clock"/>{event.time}</span><span><Icon name="pin"/>{event.venue}</span></div>
        <p className="event-modal-description">{event.description}</p><p className="event-modal-minister"><b>Ministering / Host</b>{event.minister}</p>
        {event.schedule&&<div className="event-modal-schedule"><h3>Programme schedule</h3>{event.schedule.map((s,i)=><article key={s.label}><span>0{i+1}</span><p><b>{s.label}</b><small>{s.when}<br/>{s.venue}<br/>{s.address}</small></p></article>)}</div>}
        {event.promoId&&<div className="event-modal-video"><iframe src={`https://www.youtube-nocookie.com/embed/${event.promoId}`} title={`${event.title} promotional video`} loading="lazy" allowFullScreen/></div>}
        <div className="event-modal-actions">{event.ticketUrl&&<Button href={event.ticketUrl}>Get Tickets</Button>}<Button href={eventCalendarUrl(event)} light>Add to Calendar</Button><button type="button" className="button light" onClick={share}>{copied?"Link Copied":"Share Event"}<Icon name={copied?"check":"share"}/></button></div>
        <small className="event-modal-note">Please confirm final programme information before travelling.</small>
      </div>
    </section>
  </div>
}

function NewsletterPopup({disabled=false}:{disabled?:boolean}){
  const [open,setOpen]=useState(false),[complete,setComplete]=useState(false);
  const closeRef=useRef<HTMLButtonElement>(null);
  useEffect(()=>{
    if(disabled){setOpen(false);return}
    try{if(localStorage.getItem("mfm-newsletter-subscribed")==="1")return;const until=Number(localStorage.getItem("mfm-newsletter-dismissed-until")||0);if(until>Date.now())return}catch{}
    const timer=setTimeout(()=>setOpen(true),2500);return()=>clearTimeout(timer);
  },[disabled]);
  useEffect(()=>{if(!open)return;closeRef.current?.focus();const key=(e:KeyboardEvent)=>{if(e.key==="Escape")dismiss()};document.addEventListener("keydown",key);return()=>document.removeEventListener("keydown",key)},[open]);
  function dismiss(){try{localStorage.setItem("mfm-newsletter-dismissed-until",String(Date.now()+14*24*60*60*1000))}catch{}setOpen(false)}
  function subscribe(e:FormEvent<HTMLFormElement>){e.preventDefault();try{localStorage.setItem("mfm-newsletter-subscribed","1")}catch{}setComplete(true)}
  if(!open)return null;
  return <div className="newsletter-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)dismiss()}}><section className="newsletter-card" role="dialog" aria-modal="true" aria-labelledby="newsletter-title"><button ref={closeRef} type="button" className="newsletter-close" aria-label="Close newsletter signup" onClick={dismiss}><Icon name="close"/></button>{complete?<div className="newsletter-success"><span>🔥</span><Eyebrow light>You&apos;re in</Eyebrow><h2 id="newsletter-title">The fire is lit.</h2><p>This preview has shown the success state. The production site keeps the original secure newsletter subscription function.</p><button type="button" className="button" onClick={()=>setOpen(false)}>Continue to Events <Icon name="arrow"/></button></div>:<><img src={`${LIVE}/img/logo.webp`} alt="" width="72" height="72"/><Eyebrow light>Stay connected</Eyebrow><h2 id="newsletter-title">The fire, once a month.</h2><p>Prayer points, sermons and the next crusade near you.</p><form onSubmit={subscribe}><label>Name<input name="FIRSTNAME" autoComplete="name" required placeholder="Your name"/></label><label>Email address<input name="EMAIL" autoComplete="email" type="email" required placeholder="you@example.com"/></label><button className="button" type="submit">Subscribe <Icon name="arrow"/></button></form><small>No spam. Unsubscribe anytime. Production submissions use the original newsletter function and privacy controls.</small></>}</section></div>
}

const spotlightEvents=events.filter(e=>["women-foundation-fl-august","nc-deliverance-crusade","florida-deliverance-crusade","womens-retreat"].includes(e.slug));
function EventSpotlight(){
  const [index,setIndex]=useState(0),[paused,setPaused]=useState(false),[touchStart,setTouchStart]=useState<number|null>(null);
  const event=spotlightEvents[index];
  useEffect(()=>{if(paused||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;const timer=setInterval(()=>setIndex(i=>(i+1)%spotlightEvents.length),7500);return()=>clearInterval(timer)},[paused]);
  function move(delta:number){setIndex(i=>(i+delta+spotlightEvents.length)%spotlightEvents.length)}
  return <div className="wrap spotlight-shell" onMouseEnter={()=>setPaused(true)} onMouseLeave={()=>setPaused(false)} onFocusCapture={()=>setPaused(true)} onBlurCapture={()=>setPaused(false)} onTouchStart={e=>setTouchStart(e.touches[0].clientX)} onTouchEnd={e=>{if(touchStart===null)return;const delta=e.changedTouches[0].clientX-touchStart;if(Math.abs(delta)>45)move(delta<0?1:-1);setTouchStart(null)}}>
    <article className="event-spotlight" aria-live="polite">
      <div className="event-spotlight-flyer"><img src={art(event.image)} alt={`${event.title} event flyer`} loading="lazy"/><span>{event.status}</span></div>
      <div className="event-spotlight-copy"><Eyebrow light>{String(index+1).padStart(2,"0")} / {String(spotlightEvents.length).padStart(2,"0")} · Featured gathering</Eyebrow><h3>{event.title}</h3><p className="event-spotlight-theme">{event.theme}</p><div className="event-spotlight-meta"><span><Icon name="calendar"/>{event.date}</span><span><Icon name="clock"/>{event.time}</span><span><Icon name="pin"/>{event.venue}</span></div><p>{event.description}</p><div className="event-spotlight-actions"><a className="button" href={`/events#${event.slug}`}>Event Details <Icon name="arrow"/></a>{event.ticketUrl&&<Button href={event.ticketUrl}>Get Tickets</Button>}{event.promoId&&<Button href={`https://www.youtube.com/watch?v=${event.promoId}`} light>Watch Promo</Button>}</div></div>
    </article>
    <div className="spotlight-controls"><button type="button" onClick={()=>move(-1)} aria-label="Previous featured event">←</button><div>{spotlightEvents.map((item,i)=><button type="button" className={i===index?"active":""} aria-label={`Show ${item.title}`} aria-current={i===index?"true":undefined} onClick={()=>setIndex(i)} key={item.slug}/>)}</div><button type="button" onClick={()=>move(1)} aria-label="Next featured event">→</button></div>
  </div>
}

type ContactType="Prayer Request"|"Testimony"|"Pastoral Support"|"General Message";
function PreviewContactForm({compact=false,defaultType="General Message"}:{compact?:boolean;defaultType?:ContactType}){
  const [sent,setSent]=useState(false);
  const [type,setType]=useState<ContactType>(defaultType);
  function submit(e:FormEvent){e.preventDefault();setSent(true)}
  if(sent)return <div className={compact?"form-success compact":"form-success"}><span><Icon name="check"/></span><h2>Preview confirmation</h2><p>The production form will use the original secure Netlify submission, spam protection, subject routing and success handling.</p><button onClick={()=>setSent(false)}>Review the form again</button></div>;
  return <form className={compact?"prayer-form compact":"prayer-form"} onSubmit={submit}>
    <label>Full name<input required placeholder="Your name"/></label>
    <label>Email address<input type="email" required placeholder="you@example.com"/></label>
    <label>Message type<select value={type} onChange={e=>setType(e.target.value as ContactType)}><option>Prayer Request</option><option>Testimony</option><option>Pastoral Support</option><option>General Message</option></select></label>
    <label>{type==="Prayer Request"?"How can we pray for you?":"Your message"}<textarea required rows={compact?4:6} placeholder={type==="Prayer Request"?"Share only what you are comfortable sharing":"How can the ministry assist you?"}/></label>
    <label className="check"><input type="checkbox" required/><span>I understand this preview does not transmit or store information.</span></label>
    <button className="button" type="submit">Review confirmation <Icon name="arrow"/></button>
  </form>
}

function ShareControl({title}:{title:string}){
  const [copied,setCopied]=useState(false);
  async function share(){
    const url=window.location.href;
    try{if(navigator.share)await navigator.share({title,url});else{await navigator.clipboard.writeText(url);setCopied(true);setTimeout(()=>setCopied(false),1800)}}catch{}
  }
  return <button type="button" className="share-control" onClick={share}><Icon name={copied?"check":"share"}/>{copied?"Link copied":"Share event"}</button>
}

type LatestVideo={id:string;title:string;href:string;source:string};
function useLatestYouTube(){
  const fallback:LatestVideo={id:messages[0].id,title:messages[0].title,href:`/messages/${messages[0].slug}`,source:"Most recent verified message"};
  const [latest,setLatest]=useState<LatestVideo>(fallback);
  useEffect(()=>{
    let disposed=false;
    const feed="https://www.youtube.com/feeds/videos.xml?channel_id=UCr3gSJPBQDjN8CEbj86Pyug";
    const proxies=[`https://api.allorigins.win/raw?url=${encodeURIComponent(feed)}`,`https://corsproxy.io/?${encodeURIComponent(feed)}`];
    async function sync(){
      for(const url of proxies){
        try{
          const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),6000);
          const res=await fetch(url,{signal:controller.signal});clearTimeout(timer);if(!res.ok)continue;
          const xml=await res.text();const doc=new DOMParser().parseFromString(xml,"application/xml");const entry=doc.querySelector("entry");
          const raw=entry?.querySelector("id")?.textContent||"";const id=raw.split(":").pop()||"";const title=entry?.querySelector("title")?.textContent||"Latest regional service";
          if(id&&!disposed){setLatest({id,title,href:`https://www.youtube.com/watch?v=${id}`,source:"Synced from the channel’s YouTube RSS feed"});return}
        }catch{}
      }
      if(!disposed)setLatest(fallback);
    }
    sync();const interval=setInterval(sync,300000);return()=>{disposed=true;clearInterval(interval)};
  },[]);
  return latest;
}

function getBroadcastState(){
  const ct=new Date(new Date().toLocaleString("en-US",{timeZone:"America/Chicago"}));
  const day=ct.getDay(),mins=ct.getHours()*60+ct.getMinutes();
  const liveTuesday=day===2&&mins>=1140&&mins<=1230;
  const liveThursday=day===4&&mins>=1080&&mins<=1170;
  if(liveTuesday)return {live:true,title:"Healing & Deliverance Hour",detail:"Live now · Tuesday service window"};
  if(liveThursday)return {live:true,title:"Open Heaven Encounter",detail:"Live now · Thursday service window"};
  const services=[{day:2,mins:1140,title:"Healing & Deliverance Hour",label:"Tuesday · 7:00 PM CT"},{day:4,mins:1080,title:"Open Heaven Encounter",label:"Thursday · 6:00 PM CT"}];
  const next=services.map(s=>{let days=(s.day-day+7)%7;if(days===0&&s.mins<=mins)days=7;return {...s,diff:days*1440+s.mins-mins}}).sort((a,b)=>a.diff-b.diff)[0];
  const days=Math.floor(next.diff/1440),hours=Math.floor((next.diff%1440)/60);
  return {live:false,title:next.title,detail:`Next scheduled · ${next.label}${days?` · ${days}d ${hours}h`:hours?` · ${hours}h`:""}`};
}

function useBroadcastState(){const [state,setState]=useState(getBroadcastState);useEffect(()=>{const timer=setInterval(()=>setState(getBroadcastState()),60000);return()=>clearInterval(timer)},[]);return state}

function PageHero({eyebrow,title,copy,image,actions}:{eyebrow:string;title:string;copy:string;image:string;actions?:React.ReactNode}){return <section className="page-hero">
  <img src={image} alt="" width="1600" height="900" fetchPriority="high"/><div className="page-hero-shade"/><div className="wrap page-hero-content"><Eyebrow light>{eyebrow}</Eyebrow><h1>{title}</h1><p>{copy}</p>{actions&&<div className="hero-actions">{actions}</div>}</div>
  </section>}

function Home(){const latest=useLatestYouTube();return <>
  <section className="home-hero">
    <img src={photo("hero")} alt="A worshipper lifting his hands during an MFM Mega Region 2 service" width="1900" height="1267" fetchPriority="high"/>
    <div className="home-hero-overlay"/><div className="wrap home-hero-content"><Eyebrow light>Mountain of Fire and Miracles Ministries</Eyebrow><h1>Come and encounter<br/><em>the fire of God.</em></h1><p>One regional family devoted to prayer, deliverance, the Word and the unlimited demonstration of the power of God.</p><div className="hero-actions"><Button href="/locations">Find a Church</Button><Button href="/watch" light>Watch a Service</Button></div></div>
    <div className="service-dock"><span><i/> Next regional gathering</span><b>Women Foundation Florida</b><small>August 29 · Online</small><a href="/events#women-foundation-fl-august">See details <Icon name="arrow"/></a></div>
  </section>
  <section className="quick-paths wrap">
    {[ ["New Here?","Plan your first visit","/new-here","church"], ["Find a Church","34 locations across 6 states","/locations","pin"], ["Watch","Live services and messages","/watch","play"], ["Request Prayer","Confidential prayer support","/prayer","heart"] ].map(([a,b,c,d])=><a href={c} key={a}><span><Icon name={d as IconName}/></span><div><b>{a}</b><small>{b}</small></div><Icon name="arrow"/></a>)}
  </section>
  <section id="new-here" className="section cream home-visitor"><div className="wrap home-visitor-grid"><div><Eyebrow>Your first visit</Eyebrow><h2>Come prepared. Leave transformed.</h2><p>Choose a location, review service information and know what to expect before you arrive. The production build keeps the original newcomer and Plan Your Visit pathways inside this new presentation.</p><div className="hero-actions"><Button href="/new-here">Plan Your Visit</Button><Button href="/locations" light>Choose a Location</Button></div></div><div id="visit" className="visitor-facts"><article><Icon name="church"/><b>What to expect</b><span>Passionate worship, biblical teaching and focused prayer.</span></article><article><Icon name="pin"/><b>Before traveling</b><span>Confirm branch service times, parking and children’s arrangements.</span></article><article><Icon name="heart"/><b>Prayer support</b><span>Prayer is available in person and through the confidential online form.</span></article></div></div></section>
  <section className="welcome-photo section wrap">
    <div className="welcome-image"><img src={photo("fullhouse")} alt="A full sanctuary during worship at MFM Mega Region 2" width="1200" height="900" loading="lazy"/></div>
    <div><Eyebrow>Welcome to Mega Region 2</Eyebrow><h2>A regional altar. A family of faith.</h2><p>Across Texas, Florida, Georgia, North Carolina, Oklahoma and Tennessee, our branches stand together in prayer, holiness, evangelism and deliverance.</p><p>Under the leadership of Pastor Olumide Oni and Pastor (Mrs.) Oluwatoyin Oni, the region serves people and families with the undiluted Word of God.</p><Button href="/about">Discover our story</Button></div>
  </section>
  <section className="dark-section section">
    <div className="wrap section-head"><div><Eyebrow light>What is happening now</Eyebrow><h2>Gather with expectation.</h2></div><p>Regional programmes, crusades, conferences and ministry gatherings—all connected to full event details.</p></div>
    <EventSpotlight/>
    <div className="center-action"><Button href="/events" light>Explore all events</Button></div>
  </section>
  <section className="section wrap"><div className="section-head"><div><Eyebrow>Life across the region</Eyebrow><h2>Worship. Prayer. The Word.</h2></div><p>Real ministry photography carries the story—not placeholders or generic stock images.</p></div>
    <div className="photo-mosaic"><figure className="wide"><img src={photo("worship")} alt="Congregation worshipping" loading="lazy"/><figcaption>Worship</figcaption></figure><figure><img src={photo("choir")} alt="Mega Region 2 choir and musicians ministering" loading="lazy"/><figcaption>Choir & Live Worship</figcaption></figure><figure><img src="https://mfmmegaregion2yc.org/img/hero-youth.jpg" alt="Youth and young adults worshipping at MFM Mega Region 2" loading="lazy"/><figcaption>Youth Church</figcaption></figure><figure><img src={photo("worship-bw")} alt="Hands raised in prayer" loading="lazy"/><figcaption>Prayer & Deliverance</figcaption></figure><figure><img src={photo("word")} alt="A worshipper taking notes during the message" loading="lazy"/><figcaption>The Word</figcaption></figure></div>
  </section>
  <section className="section promo-watch"><div className="wrap"><div className="section-head"><div><Eyebrow>Watch & prepare</Eyebrow><h2>Come with expectation.</h2></div><p>Official promotional videos connected to the full information and registration pathway for each gathering.</p></div><div className="promo-video-grid">{events.filter(e=>["nc-deliverance-crusade","florida-deliverance-crusade"].includes(e.slug)).map(e=><article key={e.slug}><div className="video-frame"><iframe src={`https://www.youtube-nocookie.com/embed/${e.promoId}`} title={`${e.title} promotional video`} loading="lazy" allowFullScreen/></div><div className="promo-event-copy"><small>{e.date} · {e.venue}</small><h3>{e.title}</h3><p>{e.description}</p><dl><div><dt>Theme</dt><dd>{e.theme}</dd></div><div><dt>Ministering</dt><dd>{e.minister}</dd></div></dl><div className="promo-event-actions"><a className="button" href={`/events#${e.slug}`}>View Event Details <Icon name="arrow"/></a>{e.ticketUrl&&<Button href={e.ticketUrl}>Register / Get Tickets</Button>}</div></div></article>)}</div></div></section>
  <section className="media-band"><div className="wrap media-band-grid"><div className="media-image"><img src={`https://img.youtube.com/vi/${latest.id}/maxresdefault.jpg`} alt="Latest MFM Mega Region 2 YouTube video thumbnail" loading="lazy"/><a href={latest.href} aria-label="Play the latest YouTube message"><Icon name="play"/></a></div><div><Eyebrow light>Watch & grow</Eyebrow><h2>{latest.title}</h2><p>{latest.source}</p><Button href={latest.href} light>Watch latest video</Button></div></div></section>
  <section className="section wrap location-call"><div><Eyebrow>Where the fire burns</Eyebrow><h2>Find an MFM church near you.</h2><p>Search the complete verified directory, review service information and open a dedicated page for every branch.</p><Button href="/locations">Search 34 locations</Button></div><div className="map-preview"><img src={`${LIVE}/img/branch-map.webp`} alt="Map preview showing MFM Mega Region 2 locations" loading="lazy"/><span>6 states · 34 locations</span></div></section>
  <section id="reach-out" className="section home-prayer"><div className="wrap home-prayer-grid"><article><Eyebrow light>Reach out to us</Eyebrow><h2>How can the ministry assist you?</h2><p>Prayer requests, testimonies, pastoral support and general messages use the same original form and secure handling. This homepage form opens with General Message selected.</p><div className="prayer-photo"><img src={photo("worship-bw")} alt="Congregation lifting their hands in prayer" loading="lazy"/></div></article><PreviewContactForm compact defaultType="General Message"/></div></section>
  </>}

function About(){const globalLeaders=[
  {img:"Daniel Olukoya 2",name:"Dr. D.K. Olukoya",title:"General Overseer · MFM Worldwide",position:"50% 20%",bio:"Founder and General Overseer of Mountain of Fire and Miracles Ministries worldwide. A man of prayer, a scholar and a vessel through whom the Lord has raised an end-time army across the nations.",socials:[["YT","https://youtube.com/@DANIELOLUKOYA1"],["IG","https://instagram.com/official_dkolukoya"],["FB","https://facebook.com/DR.OLUKOYA"]] as SocialLink[]},
  {img:"shade olukoya",name:"Pastor (Dr.) Mrs. Shade Olukoya",title:"Mummy G.O. · International President, MFM Women Foundation",position:"50% 18%",bio:"A woman of faith and a dedicated servant of God who stands beside the General Overseer in the ministry’s global mandate of prayer and deliverance. She leads the MFM Women Foundation across regions and nations worldwide.",socials:[["FB","https://www.facebook.com/FolashadeElizabethOlukoya"],["IG","https://instagram.com/shade.olukoya"]] as SocialLink[]},
];
const regionalLeaders=[
  {img:"pastor-oni-gold",name:"Pastor Olumide Oni",eyebrow:"Principal Regional Overseer",title:"Mega Region 2 USA & MFM North America Headquarters",position:"50% 34%",bio:["Pastor Olumide Oni is a prophet, evangelist, pastor, teacher, husband and father—a man through whom the fire of God burns brightly across nations.","His ministry journey within MFM has taken him through multiple assignments of increasing responsibility: from Kubwa to MFM Lugbe Region in Abuja, then to MFM Wuye/Utako, the International Headquarters Annex in Abuja, and now to MFM North America Headquarters at Prayer City in Houston, Texas, where he serves as Principal Regional Overseer of Mega Region 2.","Known for dynamic teaching, administrative excellence and a powerful personal testimony of God’s deliverance, Pastor Oni leads Mega Region 2 as a vibrant centre of prayer and spiritual warfare, with weekly programmes connecting believers across multiple continents."],socials:[["YT","https://youtube.com/@pastorolumideoni"],["IG","https://instagram.com/oniolumide_"],["FB","https://facebook.com/PastorOlumideOni"],["WEB","https://pastorolumideoni.netlify.app/"]] as SocialLink[],badge:"Author of 107+ anointed books"},
  {img:"mrs-oni-burgundy",name:"Pastor (Mrs.) Oluwatoyin Oni",eyebrow:"Partner in Ministry",title:"President, MFM Women Foundation · Mega Region 2 USA",position:"50% 20%",bio:["Pastor (Mrs.) Oluwatoyin Oni stands alongside Pastor Olumide Oni as a devoted partner in ministry, faith and family. Together they serve Mega Region 2 with dedication, love and the fire of the Holy Ghost.","A woman of prayer and purpose, she plays a vital role in the spiritual life and growth of the region, exemplifying the call of Proverbs 31—strength, dignity and wisdom in the house of God. As President of the MFM Women Foundation, she leads with compassion, equipping women for their God-ordained destiny."],socials:[["FB","https://www.facebook.com/oluwatoyin.oni.58"],["IG","https://instagram.com/oluwatoyin.oni.58"],["YT","https://www.youtube.com/@oluwatoyinonireal"]] as SocialLink[]},
];return <><PageHero eyebrow="About MFM Mega Region 2 USA" title="The fire that changes lives." copy="A full-gospel ministry committed to holiness, prayer, evangelism, deliverance and the revival of apostolic signs and wonders." image={photo("worship-bw")}/>
  <section className="section wrap prose-split"><div><Eyebrow>Who we are</Eyebrow><h2>Rooted in the mandate of MFM Worldwide.</h2></div><div><p>MFM Mega Region 2 USA is a regional family of Mountain of Fire and Miracles Ministries churches serving communities across six states.</p><p>We exist to propagate the gospel of Jesus Christ, prepare believers for spiritual warfare, strengthen families, plant churches and demonstrate the power of God to deliver to the uttermost.</p></div></section>
  <section className="scripture-band"><div className="wrap"><span>Obadiah 1:17</span><blockquote>“Upon mount Zion shall be deliverance, and there shall be holiness; and the house of Jacob shall possess their possessions.”</blockquote></div></section>
  <section className="section leadership-section"><div className="wrap"><div className="section-head"><div><Eyebrow>Servants of the Most High</Eyebrow><h2>Global leadership.</h2></div><p>Authoritative titles, approved photographs, original biographies and verified profile links are presented together.</p></div><div className="global-leader-grid">{globalLeaders.map(l=><article key={l.name}><img src={photo(l.img)} alt={`${l.name}, ${l.title}`} loading="lazy" style={{objectPosition:l.position}}/><div><h3>{l.name}</h3><p className="leader-role">{l.title}</p><p>{l.bio}</p><LeaderSocials name={l.name} links={l.socials}/></div></article>)}</div></div></section>
  <section className="section regional-leadership"><div className="wrap"><div className="section-head"><div><Eyebrow light>Regional leadership</Eyebrow><h2>Serving the region with prayer and fire.</h2></div><p>The fuller original profiles are restored instead of reducing the regional leaders to names and titles.</p></div><div className="regional-leader-list">{regionalLeaders.map((l,i)=><article className={i%2?"regional-leader reverse":"regional-leader"} key={l.name}><div className="regional-leader-image"><img src={photo(l.img)} alt={l.name} loading="lazy" style={{objectPosition:l.position}}/></div><div className="regional-leader-copy"><Eyebrow light>{l.eyebrow}</Eyebrow><h3>{l.name}</h3><p className="leader-role">{l.title}</p>{l.bio.map(p=><p key={p}>{p}</p>)}{l.badge&&<span className="leader-badge">{l.badge}</span>}<LeaderSocials name={l.name} links={l.socials}/></div></article>)}</div></div></section>
  <section className="section cream"><div className="wrap values-grid"><article><b>01</b><h3>Prayer</h3><p>Fervent, effectual prayer rooted in Scripture and dependence on the Holy Spirit.</p></article><article><b>02</b><h3>Deliverance</h3><p>Freedom through the power and authority of Jesus Christ.</p></article><article><b>03</b><h3>The Word</h3><p>Sound biblical teaching that equips believers for victorious Christian living.</p></article></div></section>
  </>}

function Locations(){const [query,setQuery]=useState("");const [state,setState]=useState("ALL");const [selected,setSelected]=useState(branches[0]);const states=["ALL","TX","FL","GA","NC","OK","TN","YC"];const filtered=useMemo(()=>branches.filter(b=>(state==="ALL"||b.state===state)&&(`${b.name} ${b.meta} ${b.address}`.toLowerCase().includes(query.toLowerCase()))),[query,state]);const pins=[{i:0,x:"32%",y:"63%"},{i:9,x:"39%",y:"45%"},{i:21,x:"82%",y:"76%"},{i:26,x:"72%",y:"41%"},{i:30,x:"81%",y:"28%"},{i:31,x:"46%",y:"28%"},{i:32,x:"59%",y:"33%"}];return <>
  <PageHero eyebrow="Where the fire burns" title="Find a church near you." copy="Search the complete Mega Region 2 directory by church name, city or state." image={photo("building")}/>
  <section className="location-tools wrap"><label><Icon name="search"/><span className="sr-only">Search locations</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search by church, city, state or ZIP"/></label><button type="button" onClick={()=>{setQuery("");setState("TX");setSelected(branches[0])}}><Icon name="pin"/> Find nearest preview</button></section>
  <section className="wrap location-layout"><aside className="state-filter"><b>Filter by state</b>{states.map(s=><button className={s===state?"active":""} onClick={()=>setState(s)} key={s}>{s==="ALL"?"All locations":s==="YC"?"Youth Church":s}</button>)}<small>{filtered.length} location{filtered.length===1?"":"s"} shown</small></aside>
    <div className="directory-list">{filtered.map(b=><BranchCard b={b} selected={selected.slug===b.slug} onSelect={()=>setSelected(b)} key={b.slug}/>)}{!filtered.length&&<div className="empty-state"><h3>No location found</h3><p>Try another city, ZIP code or state.</p></div>}</div>
    <aside className="directory-map"><div className="map-stage"><img src={`${LIVE}/img/branch-map.webp`} alt="Regional branch map"/>{pins.map(p=><button type="button" aria-label={`Show ${branches[p.i].name}`} className={selected.slug===branches[p.i].slug?"map-pin active":"map-pin"} style={{left:p.x,top:p.y}} onClick={()=>setSelected(branches[p.i])} key={p.i}><Icon name="pin"/></button>)}</div><div className="map-selection"><small>Selected location</small><b>{selected.name}</b><p>{selected.meta}<br/>{selected.address}</p><a href={`/branches/${selected.slug}`}>View branch details <Icon name="arrow"/></a></div><div className="map-capabilities"><span><Icon name="check"/> Map & pins</span><span><Icon name="check"/> ZIP ranking</span><span><Icon name="check"/> Branch popups</span></div></aside>
  </section></>}

function BranchCard({b,selected=false,onSelect}:{b:Branch;selected?:boolean;onSelect?:()=>void}){return <article className={selected?"branch-card selected":"branch-card"}><span>{b.state}</span><div><small>{b.meta}</small><h3>{b.name}</h3><p>{b.pastor}</p><p>{b.address}</p><button type="button" onClick={onSelect}><Icon name="pin"/> Show on map</button></div><a href={`/branches/${b.slug}`} aria-label={`View ${b.name}`}><Icon name="arrow"/></a></article>}

function BranchDetail({b}:{b:Branch}){const map=`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(b.address)}`;return <>
  <PageHero eyebrow={`${b.state} · Mega Region 2 location`} title={b.name} copy={b.meta} image={b.slug==="mfm-usa-prayer-city"?photo("fullhouse"):photo("building")} actions={<><Button href={map}>Get Directions</Button><Button href="/prayer" light>Request Prayer</Button></>}/>
  <section className="section wrap branch-detail-grid"><article><Eyebrow>Welcome</Eyebrow><h2>A place of prayer, worship and the Word.</h2><p>We look forward to welcoming you to {b.name}. Review the current information below and contact the branch before traveling for a special programme.</p><dl><div><dt>Pastor</dt><dd>{b.pastor}</dd></div><div><dt>Address</dt><dd>{b.address}</dd></div><div><dt>Services</dt><dd>{b.services}</dd></div>{b.phone&&<div><dt>Phone</dt><dd>{b.phone}</dd></div>}</dl><div className="hero-actions"><Button href={map}>Open in Maps</Button><Button href="/locations" light>All Locations</Button></div></article><aside className="branch-visual"><img src={photo("community")} alt="Members of MFM Mega Region 2 in fellowship" loading="lazy"/><div><Icon name="pin"/><b>{b.meta}</b><span>{b.address}</span></div></aside></section>
  </>}

function ProgramModal({p,onClose}:{p:(typeof programs)[number];onClose:()=>void}){
  useEffect(()=>{const key=(e:KeyboardEvent)=>{if(e.key==="Escape")onClose()};document.addEventListener("keydown",key);return()=>document.removeEventListener("keydown",key)},[onClose]);
  return <div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><section className="program-modal" role="dialog" aria-modal="true" aria-labelledby="program-modal-title"><button className="modal-close" type="button" aria-label="Close programme schedule" onClick={onClose}><Icon name="close"/></button><Eyebrow>{p.day}</Eyebrow><h2 id="program-modal-title">{p.title}</h2><p>{p.copy}</p><div className="program-schedule">{p.schedule.map((item,i)=><div key={item}><span>0{i+1}</span><b>{item}</b></div>)}</div><div className="modal-actions"><Button href="/watch">Watch Live</Button><Button href="/events" light>All Events</Button></div><small>This popup preserves the original in-page schedule flow—visitors are not redirected and asked to find the programme again.</small></section></div>
}

function Programs(){const [selected,setSelected]=useState<(typeof programs)[number]|null>(null);return <><PageHero eyebrow="Regional programmes" title="Gather. Pray. Prevail." copy="Weekly and monthly programmes that unite the region in worship, prayer, healing and deliverance." image={photo("worship")}/><section className="section wrap program-list">{programs.map((p,i)=><article key={p.slug}><div className="program-photo"><img src={art(p.image)} alt={`${p.title} programme artwork`} loading="lazy"/><span>0{i+1}</span></div><div><Eyebrow>{p.day}</Eyebrow><h2>{p.title}</h2><p>{p.copy}</p><ul><li>Prayer and the Word</li><li>Regional participation</li><li>Watch or attend as announced</li></ul><button className="button" type="button" onClick={()=>setSelected(p)}>See current schedule <Icon name="arrow"/></button></div></article>)}</section>{selected&&<ProgramModal p={selected} onClose={()=>setSelected(null)}/>}</>}

function EventCard({e,featured=false,onOpen}:{e:EventItem;featured?:boolean;onOpen?:(e:EventItem)=>void}){
  const open=()=>onOpen?.(e);
  return <article className={featured?"event-card featured":"event-card"}>{onOpen?<button type="button" onClick={open} className="event-card-image"><img src={art(e.image)} alt={`${e.title} event flyer`} loading="lazy"/><span>{e.status}</span></button>:<a href={`/events/${e.slug}`} className="event-card-image"><img src={art(e.image)} alt={`${e.title} event flyer`} loading="lazy"/><span>{e.status}</span></a>}<div><small>{e.date}</small><h3>{onOpen?<button type="button" className="event-title-button" onClick={open}>{e.title}</button>:<a href={`/events/${e.slug}`}>{e.title}</a>}</h3><p>{e.venue}</p><div className="event-card-actions">{onOpen?<button type="button" className="inline-link" onClick={open}>Event details <Icon name="arrow"/></button>:<a className="inline-link" href={`/events/${e.slug}`}>Event details <Icon name="arrow"/></a>}{e.ticketUrl&&<a className="inline-link ticket" href={e.ticketUrl} target="_blank" rel="noreferrer">Get tickets <Icon name="external"/></a>}{e.promoId&&(onOpen?<button type="button" className="inline-link promo" onClick={open}>Watch promo <Icon name="play"/></button>:<a className="inline-link promo" href={`/events/${e.slug}#promo`}>Watch promo <Icon name="play"/></a>)}</div></div></article>
}

function Events(){
  const [selected,setSelected]=useState<EventItem|null>(null);
  useEffect(()=>{const openFromHash=()=>{const slug=window.location.hash.replace(/^#/,"");if(slug){const item=events.find(e=>e.slug===slug);if(item)setSelected(item)}};openFromHash();window.addEventListener("hashchange",openFromHash);return()=>window.removeEventListener("hashchange",openFromHash)},[]);
  function openEvent(e:EventItem){setSelected(e);window.history.replaceState(null,"",`${window.location.pathname}#${e.slug}`)}
  function closeEvent(){setSelected(null);window.history.replaceState(null,"",window.location.pathname)}
  return <><PageHero eyebrow="Events & programmes" title="Come with expectation." copy="Regional crusades, conferences, retreats, prayer programmes and special gatherings." image={photo("fullhouse")}/><section className="section wrap"><div className="filter-summary"><b>Upcoming & ongoing</b><span>{events.length} events</span></div><div className="events-grid">{events.map((e,i)=><EventCard e={e} featured={i===2||i===3} onOpen={openEvent} key={e.slug}/>)}</div></section><section className="timezone-band"><div className="wrap"><Eyebrow light>Fire across time zones</Eyebrow><h2>One altar. Many locations.</h2><div className="timezone-grid"><span><b>6:00 PM</b>Central</span><span><b>7:00 PM</b>Eastern</span><span><b>11:00 PM</b>Ghana</span><span><b>12:00 AM</b>UK / Nigeria</span></div><small>Illustrative conversion for a 6:00 PM Central programme. The final system remains DST-aware.</small></div></section>{selected&&<EventModal event={selected} onClose={closeEvent}/>}<NewsletterPopup disabled={Boolean(selected)}/></>
}

function EventDetail({e}:{e:EventItem}){return <><section className="detail-hero"><div className="detail-hero-art"><img src={art(e.image)} alt={`${e.title} official event flyer`}/></div><div className="detail-hero-copy"><Eyebrow light>{e.status} · Regional event</Eyebrow><h1>{e.title}</h1><p>{e.theme}</p><div className="detail-meta"><span><Icon name="calendar"/>{e.date}</span><span><Icon name="clock"/>{e.time}</span><span><Icon name="pin"/>{e.venue}</span></div><div className="hero-actions">{e.ticketUrl&&<Button href={e.ticketUrl}>Get Tickets</Button>}{e.promoId&&<Button href="#promo" light>Watch Promo</Button>}<Button href={`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(e.title)}`} light>Add to Calendar</Button><ShareControl title={e.title}/></div></div></section><section className="section wrap event-detail-body"><article><Eyebrow>About this gathering</Eyebrow><h2>{e.theme}</h2><p>{e.description}</p><h3>Ministering / Host</h3><p>{e.minister}</p>{e.schedule&&<div className="event-schedule"><h3>Programme schedule</h3>{e.schedule.map((s,i)=><div key={s.label}><span>0{i+1}</span><p><b>{s.label}</b><small>{s.when}<br/>{s.venue} · {s.address}</small></p></div>)}</div>}<div className="event-actions-preview"><span><Icon name="check"/> Event deep link</span><span><Icon name="check"/> Calendar action</span><span><Icon name="check"/> Share fallback</span><span><Icon name="check"/> Original event data</span></div><div className="notice"><b>Verified event information</b><span>Always confirm final programme details before traveling. Online access details are shared safely and are not exposed publicly.</span></div></article><aside><img src={photo("outreach")} alt="MFM Mega Region 2 community and ministry gathering" loading="lazy"/><h3>Need assistance?</h3><p>Contact the regional office for accessibility, directions or programme questions.</p><Button href="/connect">Contact Us</Button></aside></section>{e.promoId&&<section id="promo" className="section event-promo"><div className="wrap"><div className="section-head"><div><Eyebrow light>Official event video</Eyebrow><h2>Watch the programme preview.</h2></div><p>This video remains attached to the same event record used across the homepage and Events page.</p></div><div className="video-frame large"><iframe src={`https://www.youtube-nocookie.com/embed/${e.promoId}`} title={`${e.title} promotional video`} loading="lazy" allowFullScreen/></div></div></section>}</>}

function Watch(){const latest=useLatestYouTube();const broadcast=useBroadcastState();return <><PageHero eyebrow="Watch live" title="Encounter God wherever you are." copy="Join regional services online and continue with the latest messages from Mega Region 2." image={photo("band")} actions={<a className="button" href="https://www.youtube.com/@mfmmegaregion2usa/live" target="_blank" rel="noreferrer">Open live channel <Icon name="external"/></a>}/><section className="broadcast-status"><div className="wrap"><span className={broadcast.live?"live":"scheduled"}><i/>{broadcast.live?"Live now":"Next service"}</span><b>{broadcast.title}</b><small>{broadcast.detail}</small><a href="https://www.youtube.com/@mfmmegaregion2usa/live" target="_blank" rel="noreferrer">{broadcast.live?"Watch now":"Open scheduled streams"} <Icon name="external"/></a></div></section><section className="section wrap watch-layout"><div className="video-frame"><iframe src={`https://www.youtube-nocookie.com/embed/${latest.id}`} title={latest.title} loading="lazy" allowFullScreen/><span><i/> {broadcast.live?"Live window active":"Latest available service"}</span></div><aside><Eyebrow>Automatic channel sync</Eyebrow><h2>{latest.title}</h2><p className="sync-source">{latest.source}. The preview refreshes the same audited RSS source every five minutes and retains a verified fallback.</p><dl><div><dt>Tuesday</dt><dd>Healing & Deliverance Hour · 7:00 PM CT</dd></div><div><dt>Thursday</dt><dd>Open Heaven Encounter · 6:00 PM CT</dd></div><div><dt>Weekend</dt><dd>Deliverance programmes at Prayer City</dd></div></dl><a className="channel-link" href="https://youtube.com/@mfmmegaregion2usa" target="_blank" rel="noreferrer">Open YouTube channel <Icon name="external"/></a></aside></section><section className="section cream"><div className="wrap"><div className="section-head"><div><Eyebrow>Continue watching</Eyebrow><h2>Recent messages</h2></div><Button href="/media">Open media library</Button></div><div className="message-grid">{messages.slice(0,3).map(m=><MessageCard m={m} key={m.slug}/>)}</div></div></section></>}

function MessageCard({m}:{m:MessageItem}){return <article className="message-card"><a href={`/messages/${m.slug}`}><img src={`https://img.youtube.com/vi/${m.id}/hqdefault.jpg`} alt={`${m.title} video thumbnail`} loading="lazy"/><span><Icon name="play"/></span></a><div><small>{m.program}</small><h3><a href={`/messages/${m.slug}`}>{m.title}</a></h3><p>{m.speaker}</p><div>{m.topics.map(t=><i key={t}>{t}</i>)}</div></div></article>}

function Media(){const [q,setQ]=useState("");const [program,setProgram]=useState("All");const [speaker,setSpeaker]=useState("All");const [topic,setTopic]=useState("All");const [year,setYear]=useState("All");const programs=["All",...Array.from(new Set(messages.map(m=>m.program)))];const speakers=["All",...Array.from(new Set(messages.map(m=>m.speaker)))];const topics=["All",...Array.from(new Set(messages.flatMap(m=>m.topics)))];const years=["All",...Array.from(new Set(messages.map(m=>String(m.year))))];const filtered=messages.filter(m=>(program==="All"||m.program===program)&&(speaker==="All"||m.speaker===speaker)&&(topic==="All"||m.topics.includes(topic))&&(year==="All"||String(m.year)===year)&&(`${m.title} ${m.speaker} ${m.topics.join(" ")}`.toLowerCase().includes(q.toLowerCase())));function clear(){setQ("");setProgram("All");setSpeaker("All");setTopic("All");setYear("All")}return <><PageHero eyebrow="Messages & teachings" title="Faith comes by hearing." copy="Search sermons, prayer services, healing and deliverance messages, women’s ministry and special events." image={photo("word")}/><section className="section wrap"><div className="media-filters"><label><Icon name="search"/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search messages, speaker or topic"/><span className="sr-only">Search media</span></label><div className="filter-selects"><label>Programme<select value={program} onChange={e=>setProgram(e.target.value)}>{programs.map(p=><option key={p}>{p}</option>)}</select></label><label>Speaker<select value={speaker} onChange={e=>setSpeaker(e.target.value)}>{speakers.map(p=><option key={p}>{p}</option>)}</select></label><label>Topic<select value={topic} onChange={e=>setTopic(e.target.value)}>{topics.map(p=><option key={p}>{p}</option>)}</select></label><label>Year<select value={year} onChange={e=>setYear(e.target.value)}>{years.map(p=><option key={p}>{p}</option>)}</select></label><button type="button" onClick={clear}>Clear filters</button></div><div className="quick-filter-row">{["All","Prayer","Deliverance","Healing","Breakthrough","Women"].map(p=><button className={(p==="All"&&topic==="All")||p===topic?"active":""} onClick={()=>setTopic(p)} key={p}>{p}</button>)}</div></div><p className="results-count">Showing {filtered.length} message{filtered.length===1?"":"s"}</p><div className="message-grid">{filtered.map(m=><MessageCard m={m} key={m.slug}/>)}</div>{!filtered.length&&<div className="empty-state"><h3>No message matches those filters.</h3><button onClick={clear}>Clear filters</button></div>}</section></>}

function MessageDetail({m}:{m:MessageItem}){return <><section className="message-detail-hero"><div className="wrap"><Eyebrow light>{m.program}</Eyebrow><h1>{m.title}</h1><p>{m.speaker}</p></div></section><section className="section wrap message-detail"><div className="video-frame large"><iframe src={`https://www.youtube-nocookie.com/embed/${m.id}`} title={m.title} loading="eager" allowFullScreen/></div><aside><Eyebrow>Message details</Eyebrow><h2>Watch. Pray. Share.</h2><dl><div><dt>Speaker</dt><dd>{m.speaker}</dd></div><div><dt>Programme</dt><dd>{m.program}</dd></div><div><dt>Topics</dt><dd>{m.topics.join(" · ")}</dd></div></dl><Button href="/media">Back to Library</Button></aside></section></>}

function Ministries(){const cards=[
  ["women","Women Foundation","A sisterhood of prevailing women growing through prayer, the Word, fellowship and service.",photo("women"),"/ministries/women"],
  ["gen218","Gen218 Singles","Christian singles growing in purpose, purity, spiritual maturity and preparation for God’s best.",photo("community"),"/ministries/gen218"],
  ["youth","Youth Church","A vibrant church expression equipping young people for worship, leadership and kingdom impact.","https://mfmmegaregion2yc.org/img/hero-youth.jpg","https://www.mfmmegaregion2yc.org/"],
];return <><PageHero eyebrow="Ministry life" title="Find your place to grow and serve." copy="Distinct ministry expressions connected by one regional vision and one spiritual family." image={photo("fellowship")}/><section className="section wrap ministry-grid">{cards.map(([slug,title,copy,img,href])=><article key={slug}><img src={img} alt={`${title} ministry`} loading="lazy"/><div><Eyebrow>Regional ministry</Eyebrow><h2>{title}</h2><p>{copy}</p><Button href={href}>Explore {title}</Button></div></article>)}</section></>}

function Women(){const womenEvents=events.filter(e=>e.ministry==="women");const womenMessages=messages.filter(m=>m.program==="Women Foundation");const shadeSocials:[[string,string],[string,string]]=[["FB","https://www.facebook.com/FolashadeElizabethOlukoya"],["IG","https://instagram.com/shade.olukoya"]];const toyinSocials:SocialLink[]=[["FB","https://www.facebook.com/oluwatoyin.oni.58"],["IG","https://instagram.com/oluwatoyin.oni.58"],["YT","https://www.youtube.com/@oluwatoyinonireal"]];return <><PageHero eyebrow="MFM Women Foundation" title="Prevailing women. Transforming generations." copy="Empowered to pray, equipped to serve and engaged to transform homes, churches and communities." image={photo("women2")}/><section className="section wrap leadership-feature"><img src={photo("shade olukoya")} alt="Pastor (Dr.) Mrs. Shade Olukoya" loading="lazy"/><div><Eyebrow>International leadership</Eyebrow><h2>Pastor (Dr.) Mrs. Shade Olukoya</h2><p className="leader-role">International President, MFM Women Foundation Worldwide · Mummy G.O.</p><p>A woman of extraordinary faith, deep prayer and unwavering commitment to the kingdom of God, she oversees the Women Foundation across MFM regions and nations worldwide.</p><p>Under her leadership, women are equipped, empowered and raised to walk in the authority of the Holy Ghost, recover divine purpose and serve the end-time harvest.</p><LeaderSocials name="Pastor Shade Olukoya" links={shadeSocials}/></div></section><section className="section cream"><div className="wrap leadership-feature reverse"><img src={photo("mrs-oni-burgundy")} alt="Pastor (Mrs.) Oluwatoyin Oni" loading="lazy"/><div><Eyebrow>Regional leadership</Eyebrow><h2>Pastor (Mrs.) Oluwatoyin Oni</h2><p className="leader-role">President, MFM Women Foundation · Mega Region 2 USA</p><p>A woman of deep prayer, unwavering faith and tender compassion, she carries a burden for the spiritual growth and empowerment of women across the region.</p><p>Under her leadership, the Women Foundation equips women with the Word, builds a culture of fervent prayer and provides space for healing, deliverance and restoration.</p><LeaderSocials name="Pastor Oluwatoyin Oni" links={toyinSocials}/><Button href="/events">Women’s programmes</Button></div></div></section><section className="section wrap"><div className="section-head"><div><Eyebrow>Three pillars</Eyebrow><h2>Prayer. Service. Transformation.</h2></div><p>Every programme is shaped to strengthen women spiritually, relationally and practically.</p></div><div className="values-grid"><article><b>01</b><h3>Empowered to Pray</h3><p>Women established at the altar and confident in the authority of Scripture.</p></article><article><b>02</b><h3>Equipped to Serve</h3><p>Women prepared to strengthen their families, churches and communities.</p></article><article><b>03</b><h3>Engaged to Transform</h3><p>Women carrying godly influence into every sphere of life.</p></article></div></section><section className="section ministry-feed"><div className="wrap"><div className="section-head"><div><Eyebrow>Upcoming programmes</Eyebrow><h2>Women Foundation events.</h2></div><p>This preview demonstrates the original department feed re-skinned—not replaced by hand-written cards.</p></div><div className="events-grid">{womenEvents.map(e=><EventCard e={e} key={e.slug}/>)}</div></div></section>{womenMessages.length>0&&<section className="section wrap"><div className="section-head"><div><Eyebrow>Messages for women</Eyebrow><h2>Watch and grow.</h2></div></div><div className="message-grid">{womenMessages.map(m=><MessageCard m={m} key={m.slug}/>)}</div></section>}</>}

function Gen218(){const genEvents=events.filter(e=>e.ministry==="gen218");return <><PageHero eyebrow="Gen218 Singles Ministry" title="Purpose. Purity. Preparation." copy="A Christ-centered community for singles growing spiritually and preparing for God’s best." image={photo("community")}/><section className="section wrap leadership-feature"><img src={photo("pastor-obatunsin")} alt="Pastor Segun Obatusin" loading="lazy"/><div><Eyebrow>Regional coordinator</Eyebrow><h2>Pastor Segun Obatusin</h2><p>Coordinator, Gen218 Singles Ministry · Mega Region 2 USA</p><p>Gen218 builds a prayerful and supportive community where singles grow in identity, purpose and spiritual maturity.</p><Button href="/events/gen218-regional-conference">Upcoming conference</Button></div></section><section className="section cream"><div className="wrap"><div className="section-head"><div><Eyebrow>Community pathways</Eyebrow><h2>Seen. Strengthened. Supported.</h2></div></div><div className="values-grid"><article><b>01</b><h3>Young Singles</h3><p>Building spiritual foundations and navigating purpose with wisdom.</p></article><article><b>02</b><h3>Mature Singles</h3><p>Deepening faith, fellowship and preparation for the future.</p></article><article><b>03</b><h3>Single Parents</h3><p>Prayerful community and practical encouragement for the journey.</p></article></div></div></section><section className="section ministry-feed"><div className="wrap"><div className="section-head"><div><Eyebrow>Upcoming programmes</Eyebrow><h2>Gen218 events.</h2></div><p>The event is drawn from the same regional event source used by the main Events experience.</p></div><div className="events-grid">{genEvents.map(e=><EventCard e={e} key={e.slug}/>)}</div></div></section></>}

function NewHere(){return <><PageHero eyebrow="Your first visit" title="You are welcome here." copy="Everything you need to feel prepared, comfortable and connected before attending an MFM service." image={photo("community")}/><section className="section wrap visit-grid"><article><span>01</span><h3>Choose a location</h3><p>Find the nearest Mega Region 2 branch and review its address and service information.</p><Button href="/locations">Find a Church</Button></article><article><span>02</span><h3>Know what to expect</h3><p>Expect passionate worship, biblical teaching and focused prayer. Service length varies by programme.</p></article><article><span>03</span><h3>Bring your family</h3><p>Children and families are welcome. Contact the branch for its current children’s ministry arrangements.</p></article><article><span>04</span><h3>Ask us anything</h3><p>Need accessibility, parking or programme information? The regional team is ready to help.</p><Button href="/connect">Contact Us</Button></article></section><section className="section cream"><div className="wrap faq-grid"><div><Eyebrow>Common questions</Eyebrow><h2>Plan with confidence.</h2></div><div><details open><summary>What should I wear?</summary><p>Come respectfully and comfortably. You do not need special clothing to attend.</p></details><details><summary>Where should I park?</summary><p>Parking arrangements vary by location. Open the branch page or contact the branch before your visit.</p></details><details><summary>Will someone pray with me?</summary><p>Yes. Prayer support is available, and you can also send a confidential request online.</p></details></div></div></section></>}

function Prayer(){return <><PageHero eyebrow="Confidential prayer support" title="How can we pray for you?" copy="Share your request with care. In the production site, submissions are routed securely to the ministry’s prayer team." image={photo("worship-bw")}/><section className="section wrap prayer-layout"><article><Eyebrow>Prayer changes things</Eyebrow><h2>Your request matters.</h2><p>This is the same main reach-out form used across the website, opened with Prayer Request already selected.</p><div className="privacy-note"><Icon name="heart"/><span><b>Handled with care</b>Production submissions retain the original Netlify form, honeypot protection, subject routing and success confirmation.</span></div></article><PreviewContactForm defaultType="Prayer Request"/></section></>}

function ReachOut(){return <><PageHero eyebrow="Reach out to us" title="How can the ministry assist you?" copy="Use one trusted form for prayer, testimony, pastoral support or a general message." image={photo("outreach")}/><section className="section wrap prayer-layout"><article><Eyebrow>One form · correct destination</Eyebrow><h2>Tell us how we can help.</h2><p>This route opens the shared form with General Message selected. Request Prayer actions use the same component with Prayer Request selected.</p><div className="privacy-note"><Icon name="mail"/><span><b>Original handling preserved</b>The production build keeps the current Netlify form name, honeypot, AJAX response and subject routing.</span></div></article><PreviewContactForm defaultType="General Message"/></section></>}

function Connect(){const links=[
  {name:"YouTube",copy:"Watch live & sermons",href:"https://youtube.com/@mfmmegaregion2usa",kind:"youtube",short:"YT"},
  {name:"WhatsApp",copy:"Join our channel",href:"https://whatsapp.com/channel/0029VaO63PADJ6H057Ikrl3G",kind:"whatsapp",short:"WA"},
  {name:"Facebook",copy:"Follow regional updates",href:"https://www.facebook.com/profile.php?id=61556716678081",kind:"facebook",short:"FB"},
  {name:"Instagram",copy:"Follow us",href:"https://instagram.com/mfmmegaregion2usa",kind:"instagram",short:"IG"},
  {name:"Branches",copy:"Find a church near you",href:"/locations",kind:"branches",short:"MR2"},
];return <section className="connect-hub"><div className="wrap connect-hub-grid"><article className="connect-hub-intro"><img src={`${LIVE}/img/logo.webp`} alt="MFM Mega Region 2 USA emblem" width="110" height="110"/><Eyebrow light>Mountain of Fire & Miracles · Mega Region 2 USA</Eyebrow><h1>Connect<br/>With <em>Us</em></h1><blockquote>“But upon mount Zion shall be deliverance, and there shall be holiness; and the house of Jacob shall possess their possessions.”<span>— Obadiah 1:17</span></blockquote><p>One place for everything—worship, prayer, sermons and our official channels. Pick a platform.</p></article><article className="connect-hub-links"><a className="connect-feature" href="/"><span><Icon name="church"/></span><div><b>Visit our Website</b><small>mfmmegaregion2usa.org</small></div><Icon name="arrow"/></a><div className="connect-tile-grid">{links.map(link=>{const external=/^https?:/.test(link.href);return <a className={`connect-tile ${link.kind}`} href={link.href} target={external?"_blank":undefined} rel={external?"noreferrer":undefined} key={link.name}><b>{link.short}</b><span><strong>{link.name}</strong><small>{link.copy}</small></span><Icon name={external?"external":"arrow"}/></a>})}</div></article></div></section>}

function Privacy(){return <><PageHero eyebrow="Privacy & trust" title="Clear, careful and respectful." copy="A preview of the production website’s privacy and safeguarding information." image={photo("word")}/><section className="section wrap legal-copy"><h2>Privacy principles</h2><p>This design preview does not collect, store or transmit personal information. The production website should clearly explain how prayer requests, newsletter subscriptions, analytics and contact submissions are handled.</p><h3>Prayer requests</h3><p>Requests should be accessible only to authorized ministry personnel and retained only as long as necessary for pastoral follow-up.</p><h3>Analytics</h3><p>The website currently plans to use privacy-friendly, cookieless analytics to understand general site usage.</p><h3>Children and safeguarding</h3><p>Youth and children’s content should be published only with appropriate consent and ministry safeguarding approval.</p><h3>Contact</h3><p>Questions about privacy may be directed to the regional office through the Connect page.</p></section></>}

function NotFound(){return <section className="not-found"><div><Eyebrow>Preview route</Eyebrow><h1>This page is not part of the current review set.</h1><p>Use the complete navigation to continue reviewing the full-site concept.</p><Button href="/">Return Home</Button></div></section>}

export default function SitePreview({path=""}:{path?:string}){
  const normalized=path.replace(/^\/+|\/+$/g,"").replace(/\.html$/i,"");
  useEffect(()=>{window.scrollTo({top:0,left:0,behavior:"auto"})},[normalized]);
  let page:React.ReactNode;
  if(!normalized) page=<Home/>;
  else if(normalized==="about") page=<About/>;
  else if(normalized==="locations"||normalized==="branches") page=<Locations/>;
  else if(normalized==="programs") page=<Programs/>;
  else if(normalized==="events") page=<Events/>;
  else if(normalized==="watch") page=<Watch/>;
  else if(normalized==="media"||normalized==="messages") page=<Media/>;
  else if(normalized==="ministries") page=<Ministries/>;
  else if(normalized==="ministries/women"||normalized==="women") page=<Women/>;
  else if(normalized==="ministries/gen218"||normalized==="gen218") page=<Gen218/>;
  else if(normalized==="new-here") page=<NewHere/>;
  else if(normalized==="prayer") page=<Prayer/>;
  else if(normalized==="reach-out") page=<ReachOut/>;
  else if(normalized==="connect"||normalized==="links") page=<Connect/>;
  else if(normalized==="privacy") page=<Privacy/>;
  else if(normalized.startsWith("branches/")){const slug=normalized.split("/")[1];const item=branches.find(x=>x.slug===slug);page=item?<BranchDetail b={item}/>:<NotFound/>}
  else if(normalized.startsWith("events/")){const slug=normalized.split("/")[1];const item=events.find(x=>x.slug===slug);page=item?<EventDetail e={item}/>:<NotFound/>}
  else if(normalized.startsWith("messages/")){const slug=normalized.split("/")[1];const item=messages.find(x=>x.slug===slug);page=item?<MessageDetail m={item}/>:<NotFound/>}
  else page=<NotFound/>;
  return <Shell path={normalized}>{page}</Shell>;
}
