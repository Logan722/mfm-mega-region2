import SitePreview from "./site";
export default function HomePage(){return <SitePreview/>}
