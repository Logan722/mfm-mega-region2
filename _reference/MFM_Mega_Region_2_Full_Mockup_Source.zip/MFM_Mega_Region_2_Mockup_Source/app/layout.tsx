import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={
  title:{default:"MFM Mega Region 2 USA · Full-Site Preview",template:"%s · MFM Mega Region 2 USA"},
  description:"A complete responsive, photo-forward Royal Flame website preview for MFM Mega Region 2 USA.",
  icons:{icon:"/favicon.svg",shortcut:"/favicon.svg"},
  openGraph:{title:"MFM Mega Region 2 USA · Full-Site Preview",description:"Globally refined. Unmistakably MFM.",images:["/og.png"]},
  twitter:{card:"summary_large_image",title:"MFM Mega Region 2 USA · Full-Site Preview",description:"Globally refined. Unmistakably MFM.",images:["/og.png"]}
};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>}
