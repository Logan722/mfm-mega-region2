import SitePreview from "../site";

export default async function PreviewRoute({params}:{params:Promise<{slug:string[]}>}){
  const {slug}=await params;
  return <SitePreview path={slug.join("/")}/>;
}
